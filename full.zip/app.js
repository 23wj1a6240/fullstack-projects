const $ = s => document.querySelector(s);
const money = c => '$' + (c / 100).toFixed(2);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };

let cart = load('cart', []);          // [{id, name, price_cents, quantity, stock}]
let user = load('user', null);        // {token, name}
const saveCart = () => { localStorage.setItem('cart', JSON.stringify(cart)); renderNav(); };

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (user) headers.Authorization = 'Bearer ' + user.token;
  const res = await fetch('/api' + path, { ...opts, headers, body: opts.body && JSON.stringify(opts.body) });
  const data = await res.json();
  if (!res.ok) { if (res.status === 401 && user) logout(true); throw new Error(data.error || 'Something went wrong.'); }
  return data;
}

function renderNav() {
  const n = cart.reduce((s, i) => s + i.quantity, 0);
  $('#nav').innerHTML = `<a href="#/">Shop</a><a href="#/cart">Cart (${n})</a>` +
    (user ? `<a href="#/orders">Orders</a><button id="out">Log out (${esc(user.name)})</button>`
          : `<a href="#/login">Log in</a><a href="#/register">Sign up</a>`);
  if (user) $('#out').onclick = () => logout();
}

function logout(expired) {
  user = null; localStorage.removeItem('user'); renderNav();
  location.hash = '#/login'; if (expired) toast('Your session expired. Log in again.');
}

const swatch = p => `<div class="swatch" style="background:${esc(p.color)}" aria-hidden="true">${esc(p.name[0])}</div>`;

// ---------- Views ----------
async function home() {
  $('#app').innerHTML = `<h1>Plants for every window</h1><p class="muted">Healthy houseplants, pots and tools, shipped within two days.</p>
    <div class="filters"><input id="q" placeholder="Search products" aria-label="Search products">
    <select id="cat" aria-label="Category"><option value="">All categories</option><option>Plants</option><option>Pots</option><option>Tools</option></select></div>
    <div class="grid" id="grid"></div>`;
  const draw = async () => {
    const qs = new URLSearchParams({ q: $('#q').value, category: $('#cat').value });
    const list = await api('/products?' + qs);
    $('#grid').innerHTML = list.map(p => `<a class="card" href="#/product/${p.id}">${swatch(p)}
      <div class="body"><h3>${esc(p.name)}</h3><div>${money(p.price_cents)}</div>
      ${p.stock ? '' : '<div class="muted">Sold out</div>'}</div></a>`).join('') || '<p>No products match your search.</p>';
  };
  $('#q').oninput = draw; $('#cat').onchange = draw; draw();
}

async function product(id) {
  const p = await api('/products/' + id);
  $('#app').innerHTML = `<p><a href="#/">Back to shop</a></p><div class="detail">${swatch(p)}<div>
    <h1>${esc(p.name)}</h1><div class="muted">${esc(p.category)}</div><div class="price">${money(p.price_cents)}</div>
    <p>${esc(p.description)}</p><p class="muted">${p.stock ? p.stock + ' in stock' : 'Sold out'}</p>
    <button class="btn" id="add" ${p.stock ? '' : 'disabled'}>Add to cart</button></div></div>`;
  $('#add').onclick = () => {
    const line = cart.find(i => i.id === p.id);
    if (line) line.quantity = Math.min(line.quantity + 1, p.stock);
    else cart.push({ id: p.id, name: p.name, price_cents: p.price_cents, quantity: 1, stock: p.stock });
    saveCart(); toast('Added to cart');
  };
}

function cartView() {
  if (!cart.length) { $('#app').innerHTML = '<h1>Your cart</h1><p>Your cart is empty. <a href="#/">Browse the shop</a>.</p>'; return; }
  const total = cart.reduce((s, i) => s + i.price_cents * i.quantity, 0);
  $('#app').innerHTML = `<h1>Your cart</h1>` + cart.map(i => `<div class="row"><div class="grow"><strong>${esc(i.name)}</strong>
    <div class="muted">${money(i.price_cents)} each</div></div>
    <input type="number" min="1" max="${i.stock}" value="${i.quantity}" data-id="${i.id}" aria-label="Quantity for ${esc(i.name)}">
    <button class="btn ghost" data-rm="${i.id}">Remove</button></div>`).join('') +
    `<p class="price">Total ${money(total)}</p><a class="btn" href="#/checkout" style="text-decoration:none;display:inline-block">Go to checkout</a>`;
  document.querySelectorAll('[data-id]').forEach(el => el.onchange = () => {
    const l = cart.find(i => i.id == el.dataset.id);
    l.quantity = Math.max(1, Math.min(Number(el.value) || 1, l.stock)); saveCart(); cartView();
  });
  document.querySelectorAll('[data-rm]').forEach(el => el.onclick = () => {
    cart = cart.filter(i => i.id != el.dataset.rm); saveCart(); cartView();
  });
}

function checkout() {
  if (!user) { toast('Log in to check out'); location.hash = '#/login'; return; }
  if (!cart.length) { location.hash = '#/cart'; return; }
  const total = cart.reduce((s, i) => s + i.price_cents * i.quantity, 0);
  $('#app').innerHTML = `<h1>Checkout</h1><p class="muted">${cart.length} item type(s), total ${money(total)}. Payment is simulated in this demo.</p>
    <div class="form"><textarea id="addr" rows="3" placeholder="Shipping address" aria-label="Shipping address"></textarea>
    <div class="error" id="err"></div><button class="btn" id="place">Place order</button></div>`;
  $('#place').onclick = async () => {
    try {
      const o = await api('/orders', { method: 'POST', body: { address: $('#addr').value, items: cart.map(({ id, quantity }) => ({ id, quantity })) } });
      cart = []; saveCart();
      $('#app').innerHTML = `<h1>Order #${o.id} confirmed</h1><p>Total charged: ${money(o.total_cents)}.</p><a href="#/orders">View your orders</a>`;
    } catch (e) { $('#err').textContent = e.message; }
  };
}

async function orders() {
  if (!user) { location.hash = '#/login'; return; }
  const list = await api('/orders');
  $('#app').innerHTML = '<h1>Your orders</h1>' + (list.map(o => `<div class="order"><strong>Order #${o.id}</strong>
    <span class="muted"> · ${esc(o.created_at)} · ${esc(o.status)}</span>
    <ul>${o.items.map(i => `<li>${i.quantity} × ${esc(i.name)} at ${money(i.price_cents)}</li>`).join('')}</ul>
    <strong>${money(o.total_cents)}</strong></div>`).join('') || '<p>You have not placed any orders yet.</p>');
}

function authView(mode) {
  const reg = mode === 'register';
  $('#app').innerHTML = `<h1>${reg ? 'Create an account' : 'Log in'}</h1><div class="form">
    ${reg ? '<input id="name" placeholder="Name" aria-label="Name">' : ''}
    <input id="email" type="email" placeholder="Email" aria-label="Email">
    <input id="pw" type="password" placeholder="Password" aria-label="Password">
    <div class="error" id="err"></div><button class="btn" id="go">${reg ? 'Sign up' : 'Log in'}</button></div>`;
  $('#go').onclick = async () => {
    try {
      const r = await api('/' + mode, { method: 'POST', body: { name: reg ? $('#name').value : undefined, email: $('#email').value, password: $('#pw').value } });
      user = r; localStorage.setItem('user', JSON.stringify(user)); renderNav();
      location.hash = cart.length ? '#/checkout' : '#/';
    } catch (e) { $('#err').textContent = e.message; }
  };
}

// ---------- Router ----------
async function route() {
  const [, page, arg] = location.hash.split('/');
  try {
    if (page === 'product') await product(arg);
    else if (page === 'cart') cartView();
    else if (page === 'checkout') checkout();
    else if (page === 'orders') await orders();
    else if (page === 'login' || page === 'register') authView(page);
    else await home();
  } catch (e) { $('#app').innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  window.scrollTo(0, 0);
}
addEventListener('hashchange', route);
renderNav(); route();
