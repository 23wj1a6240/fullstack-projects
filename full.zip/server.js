const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const db = new Database('shop.db');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT, price_cents INTEGER NOT NULL,
  stock INTEGER NOT NULL, category TEXT, color TEXT);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  total_cents INTEGER NOT NULL, address TEXT NOT NULL, status TEXT DEFAULT 'paid',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id), quantity INTEGER NOT NULL, price_cents INTEGER NOT NULL);
`);

if (!db.prepare('SELECT COUNT(*) c FROM products').get().c) {
  const ins = db.prepare('INSERT INTO products(name,description,price_cents,stock,category,color) VALUES(?,?,?,?,?,?)');
  [
    ['Monstera Deliciosa', 'Big split leaves. Thrives in bright, indirect light.', 3400, 12, 'Plants', '#3f7d58'],
    ['Snake Plant', 'Nearly unkillable. Tolerates low light and missed waterings.', 2200, 20, 'Plants', '#5b8c3a'],
    ['Fiddle Leaf Fig', 'A statement tree for a sunny corner.', 4800, 6, 'Plants', '#2f6b4a'],
    ['Pothos Trailing', 'Fast-growing vine for shelves and hanging pots.', 1600, 25, 'Plants', '#6aa84f'],
    ['Terracotta Pot, 6 in', 'Unglazed clay with a drainage hole and saucer.', 1200, 40, 'Pots', '#c0734f'],
    ['Ceramic Planter, Sand', 'Matte glazed planter, fits 8 in nursery pots.', 2600, 15, 'Pots', '#d8c9a8'],
    ['Brass Watering Can', 'Long spout for precise watering.', 3200, 9, 'Tools', '#b08d3c'],
    ['Pruning Shears', 'Stainless steel, sharp enough for woody stems.', 1800, 18, 'Tools', '#4a5560'],
  ].forEach(p => ins.run(...p));
}

const app = express();
app.use(express.json());
app.use(express.static('public'));

const sign = u => jwt.sign({ id: u.id, name: u.name }, SECRET, { expiresIn: '7d' });
function auth(req, res, next) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  try { req.user = jwt.verify(t, SECRET); next(); }
  catch { res.status(401).json({ error: 'Please log in to continue.' }); }
}

// Auth
app.post('/api/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6)
    return res.status(400).json({ error: 'Enter a name, an email, and a password of at least 6 characters.' });
  try {
    const r = db.prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)')
      .run(name.trim(), email.toLowerCase().trim(), bcrypt.hashSync(password, 10));
    const u = { id: r.lastInsertRowid, name };
    res.json({ token: sign(u), name });
  } catch { res.status(409).json({ error: 'An account with this email already exists.' }); }
});

app.post('/api/login', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get((req.body.email || '').toLowerCase().trim());
  if (!u || !bcrypt.compareSync(req.body.password || '', u.password))
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  res.json({ token: sign(u), name: u.name });
});

// Products
app.get('/api/products', (req, res) => {
  const { category, q } = req.query;
  let sql = 'SELECT * FROM products WHERE 1=1'; const args = [];
  if (category) { sql += ' AND category=?'; args.push(category); }
  if (q) { sql += ' AND name LIKE ?'; args.push(`%${q}%`); }
  res.json(db.prepare(sql).all(...args));
});

app.get('/api/products/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id);
  p ? res.json(p) : res.status(404).json({ error: 'Product not found.' });
});

// Orders: prices and stock are always checked on the server
const placeOrder = db.transaction((userId, items, address) => {
  let total = 0; const lines = [];
  for (const { id, quantity } of items) {
    const p = db.prepare('SELECT * FROM products WHERE id=?').get(id);
    const q = Math.floor(Number(quantity));
    if (!p || q < 1) throw new Error('An item in your cart is no longer available.');
    if (p.stock < q) throw new Error(`Only ${p.stock} left of ${p.name}.`);
    db.prepare('UPDATE products SET stock = stock - ? WHERE id=?').run(q, p.id);
    total += p.price_cents * q; lines.push([p.id, q, p.price_cents]);
  }
  const o = db.prepare('INSERT INTO orders(user_id,total_cents,address) VALUES(?,?,?)').run(userId, total, address);
  lines.forEach(l => db.prepare('INSERT INTO order_items(order_id,product_id,quantity,price_cents) VALUES(?,?,?,?)').run(o.lastInsertRowid, ...l));
  return { id: o.lastInsertRowid, total_cents: total };
});

app.post('/api/orders', auth, (req, res) => {
  const { items, address } = req.body;
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Your cart is empty.' });
  if (!address || !address.trim()) return res.status(400).json({ error: 'Enter a shipping address.' });
  try { res.json(placeOrder(req.user.id, items, address.trim())); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/orders', auth, (req, res) => {
  const orders = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.id);
  const items = db.prepare(`SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE order_id=?`);
  res.json(orders.map(o => ({ ...o, items: items.all(o.id) })));
});

app.listen(3000, () => console.log('Shop running at http://localhost:3000'));
