# Meetly: encrypted video meetings

Node.js + Express + Socket.io + SQLite backend. WebRTC, Web Crypto and canvas in a vanilla JS frontend.

## Run
    npm install
    npm start                 # http://localhost:3000
Camera and screen sharing need HTTPS, except on localhost. To serve HTTPS directly:
    TLS_KEY=key.pem TLS_CERT=cert.pem JWT_SECRET=$(openssl rand -hex 32) npm start
or put the app behind a reverse proxy (nginx, Caddy) that terminates TLS.

Try it: open two browsers, register two users, start a meeting in one and paste the invite link into the other.

## Features
- Multi-user video calls (WebRTC mesh, up to 6 people)
- Screen sharing (swaps your video track without renegotiating)
- Chat and file sharing (10 MB limit)
- Shared whiteboard with colour, pen size, eraser and clear; late joiners get the history
- User authentication (bcrypt, JWT, rate-limited login)

## Security model
- Media: WebRTC encrypts audio and video with DTLS-SRTP. It goes peer to peer, not through the server.
- Chat, files and whiteboard strokes: encrypted in the browser with AES-GCM. The 256-bit room key is in the invite link's `#` fragment, which browsers never send to the server. The server relays and stores only ciphertext.
- Anyone with the full invite link can join and read the room, so share it privately. The key is not rotated when someone leaves.
- Sockets reject connections without a valid JWT. Passwords are hashed with bcrypt (cost 12). Responses carry a strict Content-Security-Policy.
- The server sees metadata: who is in which room, and when.

## Limits and next steps
- Mesh calls get heavy past about 6 people; use an SFU such as mediasoup or LiveKit for larger rooms.
- The default config only has a public STUN server. Users behind strict NATs need a TURN server (for example coturn) added to `ICE` in `public/app.js`.
- Whiteboard history is held in server memory and disappears when the room empties or the server restarts.
