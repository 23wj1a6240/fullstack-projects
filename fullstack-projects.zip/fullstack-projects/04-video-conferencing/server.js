const fs = require('fs');
const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const MAX_PEERS = 6;

const db = new Database('meet.db');
db.exec(`CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use((_req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(self), microphone=(self), display-capture=(self)',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' ws: wss:; media-src 'self' blob:; img-src 'self' blob: data:",
  });
  next();
});
app.use(express.static('public'));

// Minimal in-memory rate limit for auth endpoints: 10 attempts per minute per IP
const hits = new Map();
setInterval(() => hits.clear(), 60_000).unref();
const limit = (req, res, next) => {
  const n = (hits.get(req.ip) || 0) + 1; hits.set(req.ip, n);
  n > 10 ? res.status(429).json({ error: 'Too many attempts. Try again in a minute.' }) : next();
};

const sign = u => jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '12h' });

app.post('/api/register', limit, (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Usernames use 3-20 letters, numbers or underscores.' });
  if (password.length < 8) return res.status(400).json({ error: 'Passwords need at least 8 characters.' });
  try {
    const r = db.prepare('INSERT INTO users(username,password) VALUES(?,?)').run(username, bcrypt.hashSync(password, 12));
    res.json({ token: sign({ id: r.lastInsertRowid, username }), username });
  } catch { res.status(409).json({ error: 'That username is taken.' }); }
});

app.post('/api/login', limit, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(String(req.body.username || '').trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.password))
    return res.status(401).json({ error: 'Username or password is incorrect.' });
  res.json({ token: sign(u), username: u.username });
});

// HTTPS when TLS_KEY and TLS_CERT are set (browsers require HTTPS for camera access off localhost)
const server = process.env.TLS_KEY && process.env.TLS_CERT
  ? require('https').createServer({ key: fs.readFileSync(process.env.TLS_KEY), cert: fs.readFileSync(process.env.TLS_CERT) }, app)
  : require('http').createServer(app);

const io = new Server(server, { maxHttpBufferSize: 25e6 });
io.use((socket, next) => {
  try { socket.user = jwt.verify(socket.handshake.auth.token, SECRET); next(); }
  catch { next(new Error('Not authenticated')); }
});

// The server only relays and stores ciphertext: the room key never leaves the participants' browsers.
const boards = new Map(); // room -> encrypted whiteboard strokes

io.on('connection', s => {
  s.on('join', (room, cb) => {
    if (!/^[a-z0-9-]{4,40}$/.test(String(room))) return cb({ error: 'Invalid meeting code.' });
    const members = [...(io.sockets.adapter.rooms.get(room) || [])];
    if (members.length >= MAX_PEERS) return cb({ error: `This meeting is full (max ${MAX_PEERS}).` });
    const peers = members.map(id => ({ id, name: io.sockets.sockets.get(id).user.username }));
    s.join(room); s.room = room;
    if (!boards.has(room)) boards.set(room, []);
    cb({ peers, board: boards.get(room) });
    s.to(room).emit('peer-joined', { id: s.id, name: s.user.username });
  });

  s.on('signal', ({ to, data }) => {
    const t = io.sockets.sockets.get(to);
    if (t && s.room && t.room === s.room) t.emit('signal', { from: s.id, data });
  });

  for (const ev of ['chat', 'file', 'draw']) {
    s.on(ev, p => {
      if (!s.room) return;
      if (ev === 'draw') { const b = boards.get(s.room); if (b.length < 20000) b.push(p); }
      s.to(s.room).emit(ev, { from: s.user.username, p });
    });
  }
  s.on('clear', () => { if (s.room) { boards.set(s.room, []); s.to(s.room).emit('clear'); } });

  s.on('disconnect', () => {
    if (!s.room) return;
    s.to(s.room).emit('peer-left', s.id);
    if (!io.sockets.adapter.rooms.get(s.room)) boards.delete(s.room);
  });
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Meetly running on port ${port}`));
