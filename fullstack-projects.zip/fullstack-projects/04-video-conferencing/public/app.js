const $ = s => document.querySelector(s);
const ICE = [{ urls: 'stun:stun.l.google.com:19302' }]; // add a TURN server here for strict NATs
const MAX_FILE = 10 * 1024 * 1024;
let user = (() => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } })();
let socket, roomKey, localStream, camTrack, screenTrack, sharing = false;
const peers = {};

const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2600); };
const show = id => ['auth', 'lobby', 'call'].forEach(x => $('#' + x).hidden = x !== id);
const rand = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => 'abcdefghijklmnopqrstuvwxyz0123456789'[b % 36]).join('');

// ---------- End-to-end encryption (AES-GCM; key lives only in the invite link's # fragment) ----------
const b64u = bytes => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
const importKey = s => crypto.subtle.importKey('raw', unb64u(s), 'AES-GCM', false, ['encrypt', 'decrypt']);
async function enc(bytes) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  return { iv, ct: new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, roomKey, bytes)) };
}
const dec = async o => new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: new Uint8Array(o.iv) }, roomKey, new Uint8Array(o.ct)));
const encJSON = obj => enc(new TextEncoder().encode(JSON.stringify(obj)));
const decJSON = async o => JSON.parse(new TextDecoder().decode(await dec(o)));

// ---------- Auth ----------
async function authenticate(mode) {
  try {
    const res = await fetch('/api/' + mode, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: $('#u').value, password: $('#pw').value }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    user = data; localStorage.setItem('user', JSON.stringify(user)); lobby();
  } catch (e) { $('#err').textContent = e.message; }
}
$('#login').onclick = () => authenticate('login');
$('#register').onclick = () => authenticate('register');
$('#out').onclick = () => { localStorage.removeItem('user'); user = null; show('auth'); };

function parseLink(s) {
  const m = /room=([a-z0-9-]{4,40})&key=([\w-]{43})/.exec(s || '');
  return m && { room: m[1], key: m[2] };
}

function lobby() {
  $('#me').textContent = user.username; show('lobby');
  const l = parseLink(location.hash); if (l) $('#link').value = location.href;
}
$('#new').onclick = () => start({ room: rand(10), key: b64u(crypto.getRandomValues(new Uint8Array(32))) });
$('#join').onclick = () => {
  const l = parseLink($('#link').value);
  l ? start(l) : $('#lerr').textContent = 'That invite link looks incomplete. Ask for it again.';
};

// ---------- Call setup ----------
async function start({ room, key }) {
  location.hash = `room=${room}&key=${key}`;
  roomKey = await importKey(key);
  try { localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true }); }
  catch {
    try { localStream = await navigator.mediaDevices.getUserMedia({ audio: true }); toast('Camera unavailable. Joining with audio only.'); }
    catch { localStream = new MediaStream(); toast('No camera or microphone. You can still watch, chat and draw.'); }
  }
  camTrack = localStream.getVideoTracks()[0];
  socket = io({ auth: { token: user.token } });
  socket.on('connect_error', () => { localStorage.removeItem('user'); toast('Your session expired. Log in again.'); show('auth'); });
  wireSocket();
  socket.emit('join', room, async res => {
    if (res.error) { $('#lerr').textContent = res.error; socket.disconnect(); return; }
    show('call'); addTile('me', user.username + ' (you)', localStream, true);
    res.peers.forEach(p => makePeer(p.id, p.name, true));
    for (const o of res.board) drawSeg(await decJSON(o).catch(() => null));
  });
}

function addTile(id, name, stream, muted) {
  let t = $('#t-' + id);
  if (!t) {
    t = document.createElement('div'); t.className = 'tile'; t.id = 't-' + id;
    t.innerHTML = '<video autoplay playsinline></video><span></span>';
    t.querySelector('span').textContent = name; $('#videos').append(t);
  }
  const v = t.querySelector('video'); v.muted = !!muted; v.srcObject = stream;
}

// ---------- WebRTC mesh: the newcomer sends offers to everyone already in the room ----------
function makePeer(id, name, initiator) {
  const pc = new RTCPeerConnection({ iceServers: ICE });
  const p = peers[id] = { pc, name, queue: Promise.resolve() };
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  for (const kind of ['audio', 'video'])
    if (!localStream.getTracks().some(t => t.kind === kind)) pc.addTransceiver(kind); // still receive remote media
  if (sharing && screenTrack) pc.getTransceivers().find(t => t.receiver.track.kind === 'video').sender.replaceTrack(screenTrack);
  pc.onicecandidate = e => e.candidate && socket.emit('signal', { to: id, data: { candidate: e.candidate } });
  pc.ontrack = e => addTile(id, name, e.streams[0]);
  if (initiator) pc.onnegotiationneeded = async () => {
    await pc.setLocalDescription();
    socket.emit('signal', { to: id, data: { description: pc.localDescription } });
  };
}

function wireSocket() {
  socket.on('peer-joined', ({ id, name }) => { makePeer(id, name, false); toast(name + ' joined'); });
  socket.on('peer-left', id => {
    const p = peers[id]; if (!p) return;
    p.pc.close(); delete peers[id]; $('#t-' + id)?.remove(); toast(p.name + ' left');
  });
  socket.on('signal', ({ from, data }) => {
    const p = peers[from]; if (!p) return;
    p.queue = p.queue.then(async () => {   // handle messages for a peer strictly in order
      if (data.description) {
        await p.pc.setRemoteDescription(data.description);
        if (data.description.type === 'offer') {
          await p.pc.setLocalDescription();
          socket.emit('signal', { to: from, data: { description: p.pc.localDescription } });
        }
      } else if (data.candidate) await p.pc.addIceCandidate(data.candidate).catch(() => {});
    }).catch(console.error);
  });

  socket.on('chat', async ({ from, p }) => { try { log(from, (await decJSON(p)).text); } catch { log('system', 'A message could not be decrypted.'); } });
  socket.on('file', async ({ from, p }) => {
    try {
      const meta = await decJSON(p.meta), data = await dec(p.data);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([data], { type: 'application/octet-stream' }));
      a.download = String(meta.name).slice(0, 120); a.textContent = `${a.download} (${Math.ceil(data.length / 1024)} KB)`;
      log(from, 'shared a file: ', a);
    } catch { log('system', 'A file could not be decrypted.'); }
  });
  socket.on('draw', async ({ p }) => drawSeg(await decJSON(p).catch(() => null)));
  socket.on('clear', () => cx.clearRect(0, 0, cv.width, cv.height));
}

// ---------- Controls ----------
const toggle = (btn, on, onLabel, offLabel) => { btn.setAttribute('aria-pressed', on); btn.textContent = on ? onLabel : offLabel; };
$('#mic').onclick = e => {
  const t = localStream.getAudioTracks()[0]; if (!t) return toast('No microphone available');
  t.enabled = !t.enabled; toggle(e.target, !t.enabled, 'Unmute', 'Mute');
};
$('#cam').onclick = e => {
  if (!camTrack) return toast('No camera available');
  camTrack.enabled = !camTrack.enabled; toggle(e.target, !camTrack.enabled, 'Start video', 'Stop video');
};
const setVideoTrack = track => {
  Object.values(peers).forEach(({ pc }) => pc.getTransceivers().find(t => t.receiver.track.kind === 'video')?.sender.replaceTrack(track));
  const preview = new MediaStream([...(track ? [track] : []), ...localStream.getAudioTracks()]);
  addTile('me', user.username + ' (you)', preview, true);
};
async function stopShare() {
  if (!sharing) return; sharing = false; screenTrack?.stop(); screenTrack = null;
  setVideoTrack(camTrack || null); toggle($('#share'), false, 'Stop sharing', 'Share screen');
}
$('#share').onclick = async () => {
  if (sharing) return stopShare();
  try {
    const s = await navigator.mediaDevices.getDisplayMedia({ video: true });
    screenTrack = s.getVideoTracks()[0]; screenTrack.onended = stopShare; sharing = true;
    setVideoTrack(screenTrack); toggle($('#share'), true, 'Stop sharing', 'Share screen');
  } catch { toast('Screen sharing was cancelled'); }
};
$('#chat').onclick = e => { $('#side').hidden = !$('#side').hidden; e.target.setAttribute('aria-pressed', !$('#side').hidden); };
$('#wb').onclick = e => {
  const on = $('#boardWrap').hidden; $('#boardWrap').hidden = !on; $('#main').classList.toggle('board', on);
  e.target.setAttribute('aria-pressed', on);
};
$('#invite').onclick = () => navigator.clipboard.writeText(location.href).then(() => toast('Invite link copied. Anyone with it can join, so share it privately.'));
$('#leave').onclick = () => { localStream.getTracks().forEach(t => t.stop()); screenTrack?.stop(); socket.disconnect(); location.hash = ''; location.reload(); };

// ---------- Chat and files ----------
function log(from, text, node) {
  const d = document.createElement('div'), b = document.createElement('b');
  b.textContent = from + ': '; d.append(b, document.createTextNode(text)); if (node) d.append(node);
  $('#log').append(d); $('#log').scrollTop = 1e9;
}
$('#chatForm').onsubmit = async e => {
  e.preventDefault(); const text = $('#msg').value.trim(); if (!text) return;
  socket.emit('chat', await encJSON({ text })); log('you', text); $('#msg').value = '';
};
$('#file').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (f.size > MAX_FILE) return toast('Files must be under 10 MB.');
  const data = new Uint8Array(await f.arrayBuffer());
  socket.emit('file', { meta: await encJSON({ name: f.name }), data: await enc(data) });
  log('you', 'shared ' + f.name);
};

// ---------- Whiteboard (strokes use 0-1 coordinates so every screen size lines up) ----------
const cv = $('#cv'), cx = cv.getContext('2d');
let last = null, erase = false;
function drawSeg(s) {
  if (!s) return;
  cx.strokeStyle = s.c; cx.lineWidth = s.w; cx.lineCap = 'round';
  cx.beginPath(); cx.moveTo(s.a * cv.width, s.b * cv.height); cx.lineTo(s.x * cv.width, s.y * cv.height); cx.stroke();
}
const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
cv.onpointerdown = e => { cv.setPointerCapture(e.pointerId); last = pos(e); };
cv.onpointermove = async e => {
  if (!last) return; const p = pos(e);
  const s = { a: last[0], b: last[1], x: p[0], y: p[1], c: erase ? '#ffffff' : $('#color').value, w: erase ? $('#size').value * 4 : +$('#size').value };
  last = p; drawSeg(s); socket.emit('draw', await encJSON(s));
};
cv.onpointerup = cv.onpointercancel = () => last = null;
$('#eraser').onclick = e => { erase = !erase; e.target.setAttribute('aria-pressed', erase); };
$('#clear').onclick = () => { if (confirm('Clear the board for everyone?')) { cx.clearRect(0, 0, cv.width, cv.height); socket.emit('clear'); } };

user ? lobby() : show('auth');
