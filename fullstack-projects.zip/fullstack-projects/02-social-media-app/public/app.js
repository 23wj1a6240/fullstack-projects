const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let user = (() => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } })();
let feedTab = 'all';

const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2200); };
const ago = s => {
  const d = (Date.now() - new Date(s.replace(' ', 'T') + 'Z')) / 1000;
  return d < 60 ? 'just now' : d < 3600 ? Math.floor(d / 60) + 'm' : d < 86400 ? Math.floor(d / 3600) + 'h' : Math.floor(d / 86400) + 'd';
};

async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  if (user) headers.Authorization = 'Bearer ' + user.token;
  const res = await fetch('/api' + path, { method, headers, body: body && JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) {
    if (res.status === 401 && user) { logout(); toast('Your session expired. Log in again.'); }
    throw new Error(data.error || 'Something went wrong.');
  }
  return data;
}

function renderNav() {
  $('#nav').innerHTML = '<a href="#/people">People</a>' + (user
    ? `<a href="#/u/${esc(user.username)}">@${esc(user.username)}</a><button id="out">Log out</button>`
    : '<a href="#/login">Log in</a><a href="#/register">Sign up</a>');
  if (user) $('#out').onclick = () => { logout(); location.hash = '#/'; };
}
function logout() { user = null; localStorage.removeItem('user'); renderNav(); }
const needLogin = () => { toast('Log in to do that'); location.hash = '#/login'; };

function postHTML(p, link = true) {
  return `<article class="post" data-id="${p.id}">
    <a class="who" href="#/u/${esc(p.username)}">@${esc(p.username)}</a> <span class="muted">${ago(p.created_at)}</span>
    <div class="text">${esc(p.body)}</div>
    <div class="actions">
      <button class="act like ${p.liked ? 'liked' : ''}" aria-pressed="${!!p.liked}">${p.liked ? '♥' : '♡'} ${p.likes}</button>
      ${link ? `<a class="act" href="#/post/${p.id}" style="text-decoration:none">💬 ${p.comments}</a>` : `<span class="act">💬 ${p.comments}</span>`}
      ${user && user.username === p.username ? '<button class="act del">Delete</button>' : ''}
    </div></article>`;
}

function wirePosts(root, reload) {
  root.querySelectorAll('.post').forEach(el => {
    const id = el.dataset.id;
    el.querySelector('.like').onclick = async () => {
      if (!user) return needLogin();
      try { await api(`/posts/${id}/like`, 'POST'); reload(); } catch (e) { toast(e.message); }
    };
    const del = el.querySelector('.del');
    if (del) del.onclick = async () => {
      if (!confirm('Delete this post?')) return;
      try { await api('/posts/' + id, 'DELETE'); if (location.hash.startsWith('#/post/')) location.hash = '#/'; else reload(); }
      catch (e) { toast(e.message); }
    };
  });
}

// ---------- Views ----------
async function home() {
  $('#app').innerHTML = `${user ? `<div class="compose"><textarea id="body" rows="2" maxlength="280" placeholder="What's on your mind?" aria-label="New post"></textarea>
      <div class="bar"><span class="muted" id="cnt">0/280</span><button class="btn primary" id="post">Post</button></div></div>
      <div class="tabs"><button data-t="all">Everyone</button><button data-t="following">Following</button></div>` : '<h1>Welcome to hum</h1><p class="muted"><a href="#/register">Sign up</a> to post, like and follow people.</p>'}
    <div id="list"></div>`;
  if (user) {
    $('#body').oninput = e => $('#cnt').textContent = e.target.value.length + '/280';
    $('#post').onclick = async () => {
      try { await api('/posts', 'POST', { body: $('#body').value }); $('#body').value = ''; $('#cnt').textContent = '0/280'; draw(); }
      catch (e) { toast(e.message); }
    };
    document.querySelectorAll('.tabs button').forEach(b => {
      b.classList.toggle('on', b.dataset.t === feedTab);
      b.onclick = () => { feedTab = b.dataset.t; home(); };
    });
  }
  async function draw() {
    const list = await api('/posts' + (user && feedTab === 'following' ? '?feed=following' : ''));
    $('#list').innerHTML = list.map(p => postHTML(p)).join('') ||
      `<p class="muted">${feedTab === 'following' ? 'Nothing here yet. Follow people from the People page.' : 'No posts yet. Be the first to post.'}</p>`;
    wirePosts($('#list'), draw);
  }
  draw();
}

async function profile(name) {
  const u = await api('/users/' + name);
  const me = user && user.username === u.username;
  $('#app').innerHTML = `<div class="profile"><h1>@${esc(u.username)}</h1>
    <div class="muted">Joined ${esc(u.created_at.slice(0, 10))}</div>
    <p id="bio">${esc(u.bio) || '<span class="muted">No bio yet.</span>'}</p>
    <div class="stats"><span><b>${u.posts}</b> posts</span><span><b id="fc">${u.followers}</b> followers</span><span><b>${u.following}</b> following</span></div>
    ${me ? '<button class="btn" id="edit">Edit bio</button>'
         : `<button class="btn ${u.is_following ? 'on' : 'primary'}" id="fol">${u.is_following ? 'Following' : 'Follow'}</button>`}</div><div id="list"></div>`;
  if (me) $('#edit').onclick = async () => {
    const bio = prompt('Your bio (160 characters max)', u.bio);
    if (bio === null) return;
    try { await api('/me', 'PUT', { bio }); profile(name); } catch (e) { toast(e.message); }
  };
  else $('#fol').onclick = async () => {
    if (!user) return needLogin();
    try { await api(`/users/${name}/follow`, 'POST'); profile(name); } catch (e) { toast(e.message); }
  };
  const draw = async () => {
    const list = await api('/posts?user=' + encodeURIComponent(name));
    $('#list').innerHTML = list.map(p => postHTML(p)).join('') || '<p class="muted">No posts yet.</p>';
    wirePosts($('#list'), draw);
  };
  draw();
}

async function postPage(id) {
  $('#app').innerHTML = '<p><a href="#/">Back to feed</a></p><div id="one"></div><div id="cm"></div>';
  const draw = async () => {
    const [p, cs] = await Promise.all([api('/posts/' + id), api(`/posts/${id}/comments`)]);
    $('#one').innerHTML = postHTML(p, false);
    wirePosts($('#one'), draw);
    $('#cm').innerHTML = (user ? `<div class="compose"><textarea id="c" rows="2" maxlength="280" placeholder="Write a comment" aria-label="Comment"></textarea>
      <div class="bar"><span></span><button class="btn primary" id="send">Comment</button></div></div>`
      : '<p class="muted"><a href="#/login">Log in</a> to comment.</p>') +
      cs.map(c => `<div class="comment"><a class="who" href="#/u/${esc(c.username)}"><b>@${esc(c.username)}</b></a>
        <span class="muted">${ago(c.created_at)}</span><div>${esc(c.body)}</div></div>`).join('');
    if (user) $('#send').onclick = async () => {
      try { await api(`/posts/${id}/comments`, 'POST', { body: $('#c').value }); draw(); } catch (e) { toast(e.message); }
    };
  };
  draw();
}

async function people() {
  $('#app').innerHTML = '<h1>People</h1><input id="q" placeholder="Search usernames" aria-label="Search usernames" style="margin:12px 0"><div id="list"></div>';
  const draw = async () => {
    const list = await api('/users?q=' + encodeURIComponent($('#q').value));
    $('#list').innerHTML = list.map(u => `<div class="person"><a href="#/u/${esc(u.username)}"><b>@${esc(u.username)}</b></a>
      <div class="muted">${esc(u.bio)}</div></div>`).join('') || '<p class="muted">No one matches that search.</p>';
  };
  $('#q').oninput = draw; draw();
}

function authView(mode) {
  const reg = mode === 'register';
  $('#app').innerHTML = `<h1>${reg ? 'Create an account' : 'Log in'}</h1><div class="form">
    <input id="u" placeholder="Username" aria-label="Username" autocomplete="username">
    <input id="pw" type="password" placeholder="Password" aria-label="Password" autocomplete="${reg ? 'new-password' : 'current-password'}">
    <div class="error" id="err"></div><button class="btn primary" id="go">${reg ? 'Sign up' : 'Log in'}</button></div>`;
  $('#go').onclick = async () => {
    try {
      user = await api('/' + mode, 'POST', { username: $('#u').value, password: $('#pw').value });
      localStorage.setItem('user', JSON.stringify(user)); renderNav(); location.hash = '#/';
    } catch (e) { $('#err').textContent = e.message; }
  };
}

async function route() {
  const [, page, arg] = location.hash.split('/');
  try {
    if (page === 'u') await profile(decodeURIComponent(arg));
    else if (page === 'post') await postPage(arg);
    else if (page === 'people') await people();
    else if (page === 'login' || page === 'register') authView(page);
    else await home();
  } catch (e) { $('#app').innerHTML = `<p class="error">${esc(e.message)}</p>`; }
}
addEventListener('hashchange', route);
renderNav(); route();
