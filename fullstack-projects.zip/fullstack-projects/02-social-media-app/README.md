# Hum: mini social media app

Express.js + SQLite backend, vanilla HTML/CSS/JS frontend.

## Run
    npm install
    npm start        # http://localhost:3000

Set `JWT_SECRET` in production. `social.db` is created on first run.

## Features
- Sign up / log in (bcrypt + JWT)
- Profiles with bio and post, follower and following counts
- Posts (280 chars), delete your own
- Comments on posts
- Like / unlike, follow / unfollow
- Home feed with Everyone and Following tabs, people search

## API
POST /api/register, /api/login
GET /api/posts (?user=name | ?feed=following), GET /api/posts/:id, POST /api/posts, DELETE /api/posts/:id
POST /api/posts/:id/like, GET|POST /api/posts/:id/comments
GET /api/users?q=, GET /api/users/:username, POST /api/users/:username/follow, PUT /api/me
