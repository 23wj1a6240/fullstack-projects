const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const db = new Database('social.db');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
  bio TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY, post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS likes(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id, post_id));
CREATE TABLE IF NOT EXISTS follows(
  follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  followee_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY(follower_id, followee_id), CHECK(follower_id != followee_id));
`);

const app = express();
app.use(express.json());
app.use(express.static('public'));

const sign = u => jwt.sign({ id: u.id, username: u.username }, SECRET, { expiresIn: '7d' });
const parse = req => {
  try { return jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); } catch { return null; }
};
const optional = (req, _res, next) => { req.user = parse(req); next(); };
const auth = (req, res, next) => {
  req.user = parse(req);
  req.user ? next() : res.status(401).json({ error: 'Log in to do that.' });
};
const clean = (s, max) => String(s || '').trim().slice(0, max);

// ---- Auth ----
app.post('/api/register', (req, res) => {
  const username = clean(req.body.username, 20).toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,20}$/.test(username))
    return res.status(400).json({ error: 'Usernames use 3-20 letters, numbers or underscores.' });
  if (password.length < 6) return res.status(400).json({ error: 'Passwords need at least 6 characters.' });
  try {
    const r = db.prepare('INSERT INTO users(username,password) VALUES(?,?)').run(username, bcrypt.hashSync(password, 10));
    res.json({ token: sign({ id: r.lastInsertRowid, username }), username });
  } catch { res.status(409).json({ error: 'That username is taken.' }); }
});

app.post('/api/login', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(clean(req.body.username, 20).toLowerCase());
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.password))
    return res.status(401).json({ error: 'Username or password is incorrect.' });
  res.json({ token: sign(u), username: u.username });
});

// ---- Posts ----
const POST_SQL = `
SELECT p.id, p.body, p.created_at, u.username,
  (SELECT COUNT(*) FROM likes WHERE post_id=p.id) AS likes,
  (SELECT COUNT(*) FROM comments WHERE post_id=p.id) AS comments,
  EXISTS(SELECT 1 FROM likes WHERE post_id=p.id AND user_id=@me) AS liked
FROM posts p JOIN users u ON u.id=p.user_id`;

app.get('/api/posts', optional, (req, res) => {
  const me = req.user?.id ?? 0;
  const { user, feed } = req.query;
  let where = '', params = { me };
  if (user) { where = 'WHERE u.username=@user'; params.user = user; }
  else if (feed === 'following' && me) {
    where = 'WHERE p.user_id IN (SELECT followee_id FROM follows WHERE follower_id=@me) OR p.user_id=@me';
  }
  res.json(db.prepare(`${POST_SQL} ${where} ORDER BY p.id DESC LIMIT 100`).all(params));
});

app.get('/api/posts/:id', optional, (req, res) => {
  const p = db.prepare(`${POST_SQL} WHERE p.id=@id`).get({ me: req.user?.id ?? 0, id: req.params.id });
  p ? res.json(p) : res.status(404).json({ error: 'Post not found.' });
});

app.post('/api/posts', auth, (req, res) => {
  const body = clean(req.body.body, 280);
  if (!body) return res.status(400).json({ error: 'Write something before posting.' });
  const r = db.prepare('INSERT INTO posts(user_id,body) VALUES(?,?)').run(req.user.id, body);
  res.json({ id: r.lastInsertRowid });
});

app.delete('/api/posts/:id', auth, (req, res) => {
  const r = db.prepare('DELETE FROM posts WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  r.changes ? res.json({ ok: true }) : res.status(403).json({ error: 'You can only delete your own posts.' });
});

app.post('/api/posts/:id/like', auth, (req, res) => {
  if (!db.prepare('SELECT 1 FROM posts WHERE id=?').get(req.params.id))
    return res.status(404).json({ error: 'Post not found.' });
  const del = db.prepare('DELETE FROM likes WHERE user_id=? AND post_id=?').run(req.user.id, req.params.id);
  if (!del.changes) db.prepare('INSERT INTO likes(user_id,post_id) VALUES(?,?)').run(req.user.id, req.params.id);
  res.json({ liked: !del.changes, likes: db.prepare('SELECT COUNT(*) c FROM likes WHERE post_id=?').get(req.params.id).c });
});

// ---- Comments ----
app.get('/api/posts/:id/comments', (req, res) => {
  res.json(db.prepare(`SELECT c.id, c.body, c.created_at, u.username FROM comments c
    JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id`).all(req.params.id));
});

app.post('/api/posts/:id/comments', auth, (req, res) => {
  const body = clean(req.body.body, 280);
  if (!body) return res.status(400).json({ error: 'Write a comment first.' });
  if (!db.prepare('SELECT 1 FROM posts WHERE id=?').get(req.params.id)) return res.status(404).json({ error: 'Post not found.' });
  db.prepare('INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)').run(req.params.id, req.user.id, body);
  res.json({ ok: true });
});

// ---- Profiles & follows ----
app.get('/api/users', (req, res) => {
  res.json(db.prepare(`SELECT username, bio FROM users WHERE username LIKE ? ORDER BY id DESC LIMIT 30`)
    .all(`%${clean(req.query.q, 20).toLowerCase()}%`));
});

app.get('/api/users/:username', optional, (req, res) => {
  const u = db.prepare('SELECT id, username, bio, created_at FROM users WHERE username=?').get(req.params.username);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  const count = (col, other) => db.prepare(`SELECT COUNT(*) c FROM follows WHERE ${col}=?`).get(u.id).c;
  res.json({
    username: u.username, bio: u.bio, created_at: u.created_at,
    followers: count('followee_id'), following: count('follower_id'),
    posts: db.prepare('SELECT COUNT(*) c FROM posts WHERE user_id=?').get(u.id).c,
    is_following: !!(req.user && db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND followee_id=?').get(req.user.id, u.id)),
  });
});

app.post('/api/users/:username/follow', auth, (req, res) => {
  const t = db.prepare('SELECT id FROM users WHERE username=?').get(req.params.username);
  if (!t) return res.status(404).json({ error: 'User not found.' });
  if (t.id === req.user.id) return res.status(400).json({ error: 'You cannot follow yourself.' });
  const del = db.prepare('DELETE FROM follows WHERE follower_id=? AND followee_id=?').run(req.user.id, t.id);
  if (!del.changes) db.prepare('INSERT INTO follows(follower_id,followee_id) VALUES(?,?)').run(req.user.id, t.id);
  res.json({ is_following: !del.changes });
});

app.put('/api/me', auth, (req, res) => {
  db.prepare('UPDATE users SET bio=? WHERE id=?').run(clean(req.body.bio, 160), req.user.id);
  res.json({ ok: true });
});

app.listen(3000, () => console.log('Hum running at http://localhost:3000'));
